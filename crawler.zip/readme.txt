
./crawl.exe -recurse=true -max_heads=1000 -depth=10 https://dir.bg https://nova.bg
